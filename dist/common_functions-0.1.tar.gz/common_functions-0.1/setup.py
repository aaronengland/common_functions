from setuptools import setup

setup(name='common_functions',
      version='0.1',
      description='Common functions',
      url='https://github.com/aaronengland/common_functions',
      author='Aaron England',
      author_email='aaron.england24.com',
      license='MIT',
      packages=['common_functions'],
      zip_safe=False)